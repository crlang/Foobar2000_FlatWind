function print_to_console(msg) {
	fb.trace(msg);
}
